clipbucket
==========

ClipBucket - An open source social networking and video sharing php software/script/application :D

P.S ClipBucket v3 is in its early beta stages, pelase do not go live without consulting with or team.